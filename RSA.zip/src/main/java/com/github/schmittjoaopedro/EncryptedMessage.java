package com.github.schmittjoaopedro;

import java.io.Serializable;

public class EncryptedMessage implements Serializable {

    public String crypto;

}
